
// import express from "express";
// import { queryDatabricks } from "../db/databricks.js";

// const router = express.Router();

// const UPLOAD = "ogc_techdept_test.skill_matrix.skill_matrix_upload";     // MASTER
// const HISTORY = "ogc_techdept_test.skill_matrix.skill_matrix_history";  // CHANGES

// const esc = (v) => String(v ?? "").replaceAll("'", "''");
// const norm = (v) => String(v ?? "").trim().replace(/\s+/g, " ");

// const normDispSql = (col) => `TRIM(REGEXP_REPLACE(${col}, '\\\\s+', ' '))`;
// const normKeySql = (col) => `LOWER(TRIM(REGEXP_REPLACE(${col}, '\\\\s+', ' ')))`;

// function getChangedBy(req) {
//   return String(req.cookies?.user_email || "").trim().toLowerCase() || "unknown";
// }

// router.get("/meta", async (req, res) => {
//   try {
//     // const rows = await queryDatabricks(`
//     //   SELECT DISTINCT Discipline
//     //   FROM ogc_techdept_test.skill_matrix.skill_matrix_upload
//     //   WHERE Discipline IS NOT NULL
//     //   ORDER BY Discipline
//     // `);
// // const rows = [
// //   ["Electrical"],
// //   ["Mechanical"],
// //   ["Process"],
// //   ["CSA"],
// //   ["Piping Engineering"],
// //   ["Instrumentation"]
// // ];
// router.get("/meta", (req, res) => {
//   return res.status(200).json({
//     disciplines: [
//       "Project Management",
//       "Process",
//       "Mechanical",
//       "CSA",
//       "Piping Design",
//       "Piping Engineering",
//       "Instrumentation",
//       "Electrical",
//     ],
//     roles: ["Engineer", "Designer"],
//   });
// });
//     return res.json({
//       disciplines: rows.map(r => r[0]),
//       roles: ["Engineer", "Designer"]
//     });

//   } catch (err) {

//     console.error("META ERROR FULL:", err);
//     console.error("META ERROR MESSAGE:", err.message);
//     console.error("META ERROR DATA:", err.response?.data);

//     return res.status(500).json({
//       message: "Meta failed",
//       error: err.message,
//       data: err.response?.data
//     });
//   }
// });


// router.get("/", async (req, res) => {
//   try {
//     const discipline = norm(req.query.discipline);
//     const role = norm(req.query.role);

//     const dFilter = discipline ? ` AND LOWER(TRIM(Discipline)) = LOWER(TRIM('${esc(discipline)}')) ` : "";
//     const rFilter = role ? ` AND LOWER(TRIM(Role)) = LOWER(TRIM('${esc(role)}')) ` : "";

//     const sql = `
// WITH base AS (
//   SELECT
//     Discipline, Role, LevelKey,
//     ${normKeySql("Skill")} AS SkillKey,
//     ${normKeySql("Subskill")} AS SubskillKey,
//     ${normDispSql("Skill")} AS SkillDisp,
//     ${normDispSql("Subskill")} AS SubskillDisp,
//     Value
//   FROM ${UPLOAD}
//   WHERE 1=1
//   ${dFilter}
//   ${rFilter}
// ),
// hist_ranked AS (
//   SELECT
//     Discipline, Role, LevelKey,
//     ${normKeySql("Skill")} AS SkillKey,
//     ${normKeySql("Subskill")} AS SubskillKey,
//     ${normDispSql("Skill")} AS SkillDisp,
//     ${normDispSql("Subskill")} AS SubskillDisp,
//     old_value,
//     new_value,
//     action,
//     changed_at,
//     changed_by,
//     ROW_NUMBER() OVER (
//       PARTITION BY Discipline, Role, LevelKey, ${normKeySql("Skill")}, ${normKeySql("Subskill")}
//       ORDER BY changed_at DESC
//     ) AS rn
//   FROM ${HISTORY}
//   WHERE 1=1
//   ${dFilter}
//   ${rFilter}
// ),
// hl AS (
//   SELECT * FROM hist_ranked WHERE rn = 1
// ),
// all_keys AS (
//   SELECT Discipline, Role, LevelKey, SkillKey, SubskillKey FROM base
//   UNION
//   SELECT Discipline, Role, LevelKey, SkillKey, SubskillKey FROM hl
// ),
// final AS (
//   SELECT
//     k.Discipline,
//     k.Role,
//     k.LevelKey,
//     COALESCE(hl.SkillDisp, b.SkillDisp) AS Skill,
//     COALESCE(hl.SubskillDisp, b.SubskillDisp) AS Subskill,
//     CASE
//       WHEN hl.action = 'DELETE' THEN NULL
//       WHEN hl.new_value IS NOT NULL THEN hl.new_value
//       ELSE b.Value
//     END AS Value,
//     hl.changed_by
//   FROM all_keys k
//   LEFT JOIN base b
//     ON b.Discipline = k.Discipline
//    AND b.Role = k.Role
//    AND b.LevelKey = k.LevelKey
//    AND b.SkillKey = k.SkillKey
//    AND b.SubskillKey = k.SubskillKey
//   LEFT JOIN hl
//     ON hl.Discipline = k.Discipline
//    AND hl.Role = k.Role
//    AND hl.LevelKey = k.LevelKey
//    AND hl.SkillKey = k.SkillKey
//    AND hl.SubskillKey = k.SubskillKey
// )

// SELECT Discipline, Role, LevelKey, Skill, Subskill, Value, changed_by
// FROM final
// WHERE Value IS NOT NULL
// ORDER BY Skill, Subskill, LevelKey
// `;

//     const rows = await queryDatabricks(sql);

//     res.json(rows.map((r) => ({
//       discipline: r[0],
//       role: r[1],
//       level: r[2],
//       category: r[3],
//       skill_name: r[4],
//       proficiency: r[5],
//       changed_by: r[6],
//     })));
// } catch (err) {
//   console.error("META ERROR FULL:", err);
//   console.error("META ERROR DATA:", err.response?.data);
//   console.error("META ERROR MESSAGE:", err.message);

//   return res.status(500).json({
//     message: "Meta failed",
//     error: err.response?.data || err.message
//   });
// }
// });

// router.post("/save", async (req, res) => {
//   try {
//     const rows = req.body;
//     const changedBy = getChangedBy(req);

//     if (!Array.isArray(rows) || rows.length === 0) {
//       return res.status(400).json({ message: "Invalid payload" });
//     }

//     const cleaned = rows.map((r) => ({
//       Discipline: norm(r.Discipline),
//       Role: norm(r.Role),
//       LevelKey: norm(r.LevelKey),
//       Skill: norm(r.Skill),
//       Subskill: norm(r.Subskill),
//       Value: norm(r.Value ?? "NA"),
//     }));

//     for (const r of cleaned) {
//       if (!r.Discipline || !r.Role || !r.LevelKey || !r.Skill || !r.Subskill) {
//         return res.status(400).json({ message: "Missing required fields" });
//       }
//     }

//     const insertSql = cleaned.map((r) => `
// SELECT
//   '${esc(r.Discipline)}' AS Discipline,
//   '${esc(r.Role)}' AS Role,
//   '${esc(r.LevelKey)}' AS LevelKey,
//   '${esc(r.Skill)}' AS Skill,
//   '${esc(r.Subskill)}' AS Subskill,
//   (
//     SELECT Value FROM (
//       WITH base AS (
//         SELECT Value
//         FROM ${UPLOAD}
//         WHERE Discipline='${esc(r.Discipline)}'
//           AND Role='${esc(r.Role)}'
//           AND LevelKey='${esc(r.LevelKey)}'
//           AND Skill='${esc(r.Skill)}'
//           AND Subskill='${esc(r.Subskill)}'
//       ),
//       hist_ranked AS (
//         SELECT new_value, action, changed_at,
//           ROW_NUMBER() OVER (ORDER BY changed_at DESC) rn
//         FROM ${HISTORY}
//         WHERE Discipline='${esc(r.Discipline)}'
//           AND Role='${esc(r.Role)}'
//           AND LevelKey='${esc(r.LevelKey)}'
//           AND Skill='${esc(r.Skill)}'
//           AND Subskill='${esc(r.Subskill)}'
//       ),
//       hist_latest AS (
//         SELECT * FROM hist_ranked WHERE rn=1
//       )
//       SELECT
//         CASE
//           WHEN (SELECT action FROM hist_latest)='DELETE' THEN NULL
//           WHEN (SELECT new_value FROM hist_latest) IS NOT NULL THEN (SELECT new_value FROM hist_latest)
//           ELSE (SELECT Value FROM base)
//         END AS Value
//     )
//   ) AS old_value,
//   '${esc(r.Value)}' AS new_value,
//   CASE
//     WHEN (
//       SELECT COUNT(*) FROM ${UPLOAD}
//       WHERE Discipline='${esc(r.Discipline)}'
//         AND Role='${esc(r.Role)}'
//         AND LevelKey='${esc(r.LevelKey)}'
//         AND Skill='${esc(r.Skill)}'
//         AND Subskill='${esc(r.Subskill)}'
//     ) > 0 THEN 'UPDATE'
//     ELSE 'INSERT'
//   END AS action,
//   CURRENT_TIMESTAMP() AS changed_at,
//   '${esc(changedBy)}' AS changed_by
// `).join("\nUNION ALL\n");

//     const historyInsert = `
// INSERT INTO ${HISTORY}
// (Discipline, Role, LevelKey, Skill, Subskill, old_value, new_value, action, changed_at, changed_by)
// ${insertSql}
// `;

//     await queryDatabricks(historyInsert);

//     res.json({ success: true, count: cleaned.length, changed_by: changedBy });
//   } catch (err) {
//     console.error("SAVE ERROR:", err.response?.data || err.message);
//     res.status(500).json({ message: "Save failed", error: err.message });
//   }
// });

// router.post("/row/delete", async (req, res) => {
//   try {
//     const changedBy = getChangedBy(req);

//     const Discipline = norm(req.body?.Discipline);
//     const Role = norm(req.body?.Role);
//     const Skill = norm(req.body?.Skill);
//     const Subskill = norm(req.body?.Subskill);

//     if (!Discipline || !Role || !Skill || !Subskill) {
//       return res.status(400).json({ message: "Missing required fields" });
//     }

//     const roleLevels =
//       Role.toLowerCase() === "designer"
//         ? ["L5", "L6", "L7", "L8", "L9", "L10", "L11", "L12", "L13", "L14", "L15"]
//         : ["L7", "L8", "L9", "L10", "L11", "L12", "L13", "L14", "L15", "L16", "L17"];

//     const deleteUnion = roleLevels.map((lvl) => `
// SELECT
//   '${esc(Discipline)}' AS Discipline,
//   '${esc(Role)}' AS Role,
//   '${esc(lvl)}' AS LevelKey,
//   '${esc(Skill)}' AS Skill,
//   '${esc(Subskill)}' AS Subskill,
//   NULL AS old_value,
//   NULL AS new_value,
//   'DELETE' AS action,
//   CURRENT_TIMESTAMP() AS changed_at,
//   '${esc(changedBy)}' AS changed_by
// `).join("\nUNION ALL\n");

//     const sql = `
// INSERT INTO ${HISTORY}
// (Discipline, Role, LevelKey, Skill, Subskill, old_value, new_value, action, changed_at, changed_by)
// ${deleteUnion}
// `;

//     await queryDatabricks(sql);

//     res.json({ success: true, changed_by: changedBy });
//   } catch (err) {
//     console.error("DELETE ERROR:", err.response?.data || err.message);
//     res.status(500).json({ message: "Delete failed" });
//   }
// });

// export default router;

import express from "express";
import { queryDatabricks } from "../db/databricks.js";

console.log("SKILL MATRIX ROUTES LOADED");

const router = express.Router();

const UPLOAD = "ogc_techdept_test.skill_matrix.skill_matrix_upload";
const HISTORY = "ogc_techdept_test.skill_matrix.skill_matrix_history";

const DISCIPLINES = [
  "Project Management",
  "Process",
  "Mechanical",
  "CSA",
  "Piping Design",
  "Piping Engineering",
  "Instrumentation",
  "Electrical",
];

const ROLES = ["Engineer", "Designer"];

const ENGINEER_LEVELS = [
  "L7",
  "L8",
  "L9",
  "L10",
  "L11",
  "L12",
  "L13",
  "L14",
  "L15",
  "L16",
  "L17",
];

const DESIGNER_LEVELS = [
  "L5",
  "L6",
  "L7",
  "L8",
  "L9",
  "L10",
  "L11",
  "L12",
  "L13",
  "L14",
  "L15",
];

const esc = (v) => String(v ?? "").replaceAll("'", "''");
const norm = (v) => String(v ?? "").trim().replace(/\s+/g, " ");

const normDispSql = (col) => `TRIM(REGEXP_REPLACE(${col}, '\\\\s+', ' '))`;
const normKeySql = (col) => `LOWER(TRIM(REGEXP_REPLACE(${col}, '\\\\s+', ' ')))`;

function getChangedBy(req) {
  return String(req.cookies?.user_email || "").trim().toLowerCase() || "unknown";
}

function levelsForRole(role) {
  return String(role || "").toLowerCase() === "designer"
    ? DESIGNER_LEVELS
    : ENGINEER_LEVELS;
}

router.get("/meta", (req, res) => {
  console.log("META ROUTE HIT");

  return res.status(200).json({
    disciplines: DISCIPLINES,
    roles: ROLES,
  });
});


router.get("/", async (req, res) => {
  try {
    const discipline = norm(req.query.discipline);
    const role = norm(req.query.role);

    const dFilter = discipline
      ? ` AND ${normKeySql("Discipline")} = LOWER('${esc(discipline)}') `
      : "";

    const rFilter = role
      ? ` AND ${normKeySql("Role")} = LOWER('${esc(role)}') `
      : "";

    const sql = `
WITH base AS (
  SELECT
    ${normDispSql("Discipline")} AS Discipline,
    ${normDispSql("Role")} AS Role,
    ${normDispSql("LevelKey")} AS LevelKey,
    ${normKeySql("Skill")} AS SkillKey,
    ${normKeySql("Subskill")} AS SubskillKey,
    ${normDispSql("Skill")} AS SkillDisp,
    ${normDispSql("Subskill")} AS SubskillDisp,
    Value
  FROM ${UPLOAD}
  WHERE 1=1
  ${dFilter}
  ${rFilter}
),
hist_ranked AS (
  SELECT
    ${normDispSql("Discipline")} AS Discipline,
    ${normDispSql("Role")} AS Role,
    ${normDispSql("LevelKey")} AS LevelKey,
    ${normKeySql("Skill")} AS SkillKey,
    ${normKeySql("Subskill")} AS SubskillKey,
    ${normDispSql("Skill")} AS SkillDisp,
    ${normDispSql("Subskill")} AS SubskillDisp,
    old_value,
    new_value,
    action,
    changed_at,
    changed_by,
    ROW_NUMBER() OVER (
      PARTITION BY
        ${normKeySql("Discipline")},
        ${normKeySql("Role")},
        ${normKeySql("LevelKey")},
        ${normKeySql("Skill")},
        ${normKeySql("Subskill")}
      ORDER BY changed_at DESC
    ) AS rn
  FROM ${HISTORY}
  WHERE 1=1
  ${dFilter}
  ${rFilter}
),
hl AS (
  SELECT * FROM hist_ranked WHERE rn = 1
),
all_keys AS (
  SELECT Discipline, Role, LevelKey, SkillKey, SubskillKey FROM base
  UNION
  SELECT Discipline, Role, LevelKey, SkillKey, SubskillKey FROM hl
),
final AS (
  SELECT
    k.Discipline,
    k.Role,
    k.LevelKey,
    COALESCE(hl.SkillDisp, b.SkillDisp) AS Skill,
    COALESCE(hl.SubskillDisp, b.SubskillDisp) AS Subskill,
    CASE
      WHEN hl.action = 'DELETE' THEN NULL
      WHEN hl.new_value IS NOT NULL THEN hl.new_value
      ELSE b.Value
    END AS Value,
    hl.changed_by
  FROM all_keys k
  LEFT JOIN base b
    ON b.Discipline = k.Discipline
   AND b.Role = k.Role
   AND b.LevelKey = k.LevelKey
   AND b.SkillKey = k.SkillKey
   AND b.SubskillKey = k.SubskillKey
  LEFT JOIN hl
    ON hl.Discipline = k.Discipline
   AND hl.Role = k.Role
   AND hl.LevelKey = k.LevelKey
   AND hl.SkillKey = k.SkillKey
   AND hl.SubskillKey = k.SubskillKey
)
SELECT Discipline, Role, LevelKey, Skill, Subskill, Value, changed_by
FROM final
WHERE Value IS NOT NULL
ORDER BY Skill, Subskill, LevelKey
`;

    const rows = await queryDatabricks(sql);

    return res.json(
      rows.map((r) => ({
        discipline: r[0],
        role: r[1],
        level: r[2],
        category: r[3],
        skill_name: r[4],
        proficiency: r[5],
        changed_by: r[6],
      }))
    );
  } catch (err) {
    console.error("MATRIX ERROR FULL:", err);
    console.error("MATRIX ERROR DATA:", err.response?.data);
    console.error("MATRIX ERROR MESSAGE:", err.message);

    return res.status(500).json({
      message: "Matrix fetch failed",
      error: err.response?.data || err.message,
    });
  }
});

/**
 * SAVE / UPDATE / ADD ROW DATA
 */
router.post("/save", async (req, res) => {
  try {
    const rows = req.body;
    const changedBy = getChangedBy(req);

    if (!Array.isArray(rows) || rows.length === 0) {
      return res.status(400).json({ message: "Invalid payload" });
    }

    const cleaned = rows.map((r) => ({
      Discipline: norm(r.Discipline),
      Role: norm(r.Role),
      LevelKey: norm(r.LevelKey),
      Skill: norm(r.Skill),
      Subskill: norm(r.Subskill),
      Value: norm(r.Value ?? "NA"),
    }));

    for (const r of cleaned) {
      if (!r.Discipline || !r.Role || !r.LevelKey || !r.Skill || !r.Subskill) {
        return res.status(400).json({ message: "Missing required fields" });
      }
    }

    const insertSql = cleaned
      .map(
        (r) => `
SELECT
  '${esc(r.Discipline)}' AS Discipline,
  '${esc(r.Role)}' AS Role,
  '${esc(r.LevelKey)}' AS LevelKey,
  '${esc(r.Skill)}' AS Skill,
  '${esc(r.Subskill)}' AS Subskill,
  (
    SELECT Value FROM (
      WITH base AS (
        SELECT Value
        FROM ${UPLOAD}
        WHERE ${normKeySql("Discipline")} = LOWER('${esc(r.Discipline)}')
          AND ${normKeySql("Role")} = LOWER('${esc(r.Role)}')
          AND ${normKeySql("LevelKey")} = LOWER('${esc(r.LevelKey)}')
          AND ${normKeySql("Skill")} = LOWER('${esc(r.Skill)}')
          AND ${normKeySql("Subskill")} = LOWER('${esc(r.Subskill)}')
        LIMIT 1
      ),
      hist_ranked AS (
        SELECT new_value, action, changed_at,
          ROW_NUMBER() OVER (ORDER BY changed_at DESC) rn
        FROM ${HISTORY}
        WHERE ${normKeySql("Discipline")} = LOWER('${esc(r.Discipline)}')
          AND ${normKeySql("Role")} = LOWER('${esc(r.Role)}')
          AND ${normKeySql("LevelKey")} = LOWER('${esc(r.LevelKey)}')
          AND ${normKeySql("Skill")} = LOWER('${esc(r.Skill)}')
          AND ${normKeySql("Subskill")} = LOWER('${esc(r.Subskill)}')
      ),
      hist_latest AS (
        SELECT * FROM hist_ranked WHERE rn = 1
      )
      SELECT
        CASE
          WHEN (SELECT action FROM hist_latest) = 'DELETE' THEN NULL
          WHEN (SELECT new_value FROM hist_latest) IS NOT NULL THEN (SELECT new_value FROM hist_latest)
          ELSE (SELECT Value FROM base)
        END AS Value
    )
  ) AS old_value,
  '${esc(r.Value)}' AS new_value,
  CASE
    WHEN (
      SELECT COUNT(*)
      FROM ${UPLOAD}
      WHERE ${normKeySql("Discipline")} = LOWER('${esc(r.Discipline)}')
        AND ${normKeySql("Role")} = LOWER('${esc(r.Role)}')
        AND ${normKeySql("LevelKey")} = LOWER('${esc(r.LevelKey)}')
        AND ${normKeySql("Skill")} = LOWER('${esc(r.Skill)}')
        AND ${normKeySql("Subskill")} = LOWER('${esc(r.Subskill)}')
    ) > 0 THEN 'UPDATE'
    ELSE 'INSERT'
  END AS action,
  CURRENT_TIMESTAMP() AS changed_at,
  '${esc(changedBy)}' AS changed_by
`
      )
      .join("\nUNION ALL\n");

    const historyInsert = `
INSERT INTO ${HISTORY}
(Discipline, Role, LevelKey, Skill, Subskill, old_value, new_value, action, changed_at, changed_by)
${insertSql}
`;

    await queryDatabricks(historyInsert);

    return res.json({
      success: true,
      count: cleaned.length,
      changed_by: changedBy,
    });
  } catch (err) {
    console.error("SAVE ERROR FULL:", err);
    console.error("SAVE ERROR DATA:", err.response?.data);
    console.error("SAVE ERROR MESSAGE:", err.message);

    return res.status(500).json({
      message: "Save failed",
      error: err.response?.data || err.message,
    });
  }
});

/**
 * DELETE FULL ROW ACROSS LEVELS
 */
router.post("/row/delete", async (req, res) => {
  try {
    const changedBy = getChangedBy(req);

    const Discipline = norm(req.body?.Discipline);
    const Role = norm(req.body?.Role);
    const Skill = norm(req.body?.Skill);
    const Subskill = norm(req.body?.Subskill);

    if (!Discipline || !Role || !Skill || !Subskill) {
      return res.status(400).json({ message: "Missing required fields" });
    }

    const roleLevels = levelsForRole(Role);

    const deleteUnion = roleLevels
      .map(
        (lvl) => `
SELECT
  '${esc(Discipline)}' AS Discipline,
  '${esc(Role)}' AS Role,
  '${esc(lvl)}' AS LevelKey,
  '${esc(Skill)}' AS Skill,
  '${esc(Subskill)}' AS Subskill,
  NULL AS old_value,
  NULL AS new_value,
  'DELETE' AS action,
  CURRENT_TIMESTAMP() AS changed_at,
  '${esc(changedBy)}' AS changed_by
`
      )
      .join("\nUNION ALL\n");

    const sql = `
INSERT INTO ${HISTORY}
(Discipline, Role, LevelKey, Skill, Subskill, old_value, new_value, action, changed_at, changed_by)
${deleteUnion}
`;

    await queryDatabricks(sql);

    return res.json({
      success: true,
      changed_by: changedBy,
    });
  } catch (err) {
    console.error("DELETE ERROR FULL:", err);
    console.error("DELETE ERROR DATA:", err.response?.data);
    console.error("DELETE ERROR MESSAGE:", err.message);

    return res.status(500).json({
      message: "Delete failed",
      error: err.response?.data || err.message,
    });
  }
});

export default router;